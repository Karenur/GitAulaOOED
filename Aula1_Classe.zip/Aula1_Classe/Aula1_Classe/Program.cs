﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula1_Classe
{
    class Program
    {
        static void Main(string[] args)
        {

            Cachorro cachorro1 = new Cachorro();
            Cachorro cachorro2 = new Cachorro();

            Cachorro[] cachorros = { cachorro1, cachorro2 };

            cachorro1.nome = "Bone";
            cachorro1.raca = "Maltez";
            cachorro1.idade = 2;
            cachorro1.peso = 3.5f;           

            cachorro2.nome = "Barao";
            cachorro2.raca = "PitBull";
            cachorro2.idade = 4;
            cachorro2.peso = 14.8f;          

         
            foreach(Cachorro item in cachorros)
            {
                Console.WriteLine($"O cachorro se chama {item.nome}");
                Console.WriteLine($"Ele é da raça {item.raca}");
                Console.WriteLine($"Ele tem {item.idade} anos");
                Console.WriteLine($"E pesa {item.peso} Kg");
                item.Latir();
                item.AbanarRabo();
                Console.WriteLine("\n\n");              
            }

            

            Console.ReadLine();
        }

    }
}
