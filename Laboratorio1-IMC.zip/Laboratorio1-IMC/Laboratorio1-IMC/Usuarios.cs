﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio1_IMC
{
    class Usuarios
    {
        public string nome;
        public int idade;
        public float altura;
        public float peso;
        public float imc;
        public string situacao;
        public float meta;
        

        public Usuarios(string nome, int idade, float altura, float peso, float imc, string situacao, float meta)
        {
            this.nome = nome;
            this.idade = idade;
            this.altura = altura;
            this.peso = peso;
            this.imc = imc;
            this.situacao = situacao;
            this.meta = meta;
        }

        public void CalcularIMC()
        {
            imc = peso / (altura*altura);
            if(imc >= 18.5f & imc < 25 )
            {               
                situacao = "normal";
            }
            if (imc >= 25 & imc < 30)
            {
                situacao = "sobrePeso";       
            }
            if (imc >= 30 & imc < 35)
            {                
                situacao = "Obesidade garu1";
            }
            if (imc >= 35 & imc < 40)
            {                
                situacao = "Obesidade garu2";
            }
            if (imc >=40 )
            {                
                situacao = "Obesidade garu3";
            }

        }
        public void NovaMeta()
        {
            
                float dif;
                dif = imc - 22;
                meta = peso - ((dif) * altura * altura);
           
        }
        public void Infos()
        {
            Console.WriteLine($"Nome: {nome}");
            Console.WriteLine($"Peso: {peso} Kg");
            Console.WriteLine($"Altura: {altura}m");
            CalcularIMC();
            Console.WriteLine($"IMC: {imc}");
            Console.WriteLine($"Situacao: {situacao}");
            NovaMeta();
            if (imc > 25)
            {
                Console.WriteLine($"Meta de peso: {meta}Kg");
            }
            else
            {
                Console.WriteLine("Voce esta bem, nao tem uma meta de peso");
            }

        }


    }
}
