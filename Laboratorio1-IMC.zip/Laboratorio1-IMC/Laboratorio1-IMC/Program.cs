﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio1_IMC
{
    class Program
    {
        static void Main(string[] args)
        {
            Usuarios userBob = new Usuarios("Bob Nelson",37,1.70f,78,0,"",0);
            Usuarios userTestolfo = new Usuarios("Testolfo Rocha", 43, 1.65f, 60, 0, "", 0);
            Usuarios userLisa = new Usuarios("Lisa Leite",22,1.72f,92,0, "", 0);

            userBob.Infos();
            Console.ReadLine();

            userLisa.Infos();
            Console.ReadLine();

            userTestolfo.Infos();
            Console.ReadLine();

        }
    }
}
