﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula01_ProjetoCarro
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro meuCarro = new Carro("cinza",2017,"Cadillac",0,180,false);
            
                      

            Console.WriteLine($"O meu carro é do modelo {meuCarro.modelo},");
            Console.WriteLine($"do ano {meuCarro.anoFabricacao},cor {meuCarro.cor},");
            Console.WriteLine($"e alcança até {meuCarro.velocidadeMaxima} Km/h.");
            Console.ReadLine();
            meuCarro.Ligar();
            Console.ReadLine();
            meuCarro.Acelerar();            
            Console.ReadLine();
            meuCarro.Acelerar();            
            Console.ReadLine();
            meuCarro.Acelerar();            
            Console.ReadLine();
            meuCarro.Freiar();            
            Console.ReadLine();
            meuCarro.Freiar();            
            Console.ReadLine();
            meuCarro.Freiar();            
            Console.ReadLine(); 





            meuCarro.Desligar();
            Console.ReadLine();




        }
    }
}
